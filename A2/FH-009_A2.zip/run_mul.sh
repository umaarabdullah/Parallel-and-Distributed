# cmd.exe /c start cmd.exe /c wsl.exe -- bash -c "cd Matrix_Op_RPC; ./matrixOp_client localhost mul;" 
gnome-terminal -- bash -c "cd Matrix_Op_RPC; ./matrixOp_client localhost mul;" 
echo "Matrix Multiplication Completed"