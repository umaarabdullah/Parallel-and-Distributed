# cmd.exe /c start cmd.exe /c wsl.exe -- bash -c "cd Matrix_Op_RPC; ./matrixOp_client localhost transpose;" 
gnome-terminal -- bash -c "cd Matrix_Op_RPC; ./matrixOp_client localhost transpose;" 
echo "Matrix Transpose Completed"