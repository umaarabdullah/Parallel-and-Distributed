# cmd.exe /c start cmd.exe /c wsl.exe -- bash -c "cd Matrix_Op_RPC; ./matrixOp_client localhost inverse;" 
gnome-terminal -- bash -c "cd Matrix_Op_RPC; ./matrixOp_client localhost inverse;" 
echo "Matrix Inverse Completed"