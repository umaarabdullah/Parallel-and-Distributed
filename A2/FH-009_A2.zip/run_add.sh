
# cmd.exe /c start cmd.exe /c wsl.exe -- bash -c "cd Matrix_Op_RPC; ./matrixOp_client localhost add;" 
gnome-terminal -- bash -c "cd Matrix_Op_RPC; ./matrixOp_client localhost add;" 
echo "Matrix Addition Completed"